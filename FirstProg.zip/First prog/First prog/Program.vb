Imports System

Module Prog1
    'First VB Program - Note'
    Sub Main()
        'Main program header'

        'Declarations'
        Dim myMessage As String 'Dim followed by identifier the As then datatype'
        'Main body'
        myMessage = "Hello world" 'Identifier -> Assignment -> text
        Console.WriteLine("Please type in your message")
        'Command for screen output ("literal string (e.g. actual text)")
        myMessage = Console.ReadLine()
        'Command for screen input (variable to be assigned)'
        Console.WriteLine("My message to you is: " & myMessage)
        'Command for screen output (literal string then comma then variable to output)'
        Console.ReadLine()




    End Sub
End Module
