﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1

{
    class Program
    {
        static void Main(string[] args)
        {
            string mymessage = "Hello World!";
            Console.WriteLine(mymessage);
            Console.WriteLine("Please type in your message");
            mymessage = Console.ReadLine();
            Console.WriteLine("My message message to you is: " + mymessage);
            Console.ReadLine();
        }
    }
}
