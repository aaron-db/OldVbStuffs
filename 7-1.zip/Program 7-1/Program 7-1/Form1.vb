﻿Public Class Form1
    Private Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        Dim Number As Integer
        Dim Index As Integer
        Dim Result As Integer

        Number = txtNumber.Text

        For Index = 2 To 12
            Result = Index * Number
            lstOutput.Items.Add(Number & " x " & Index & " = " & Result)
        Next
    End Sub
End Class
