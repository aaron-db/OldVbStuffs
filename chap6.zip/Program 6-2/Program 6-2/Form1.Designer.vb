﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.chkKnife = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lstBrands = New System.Windows.Forms.ListBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkFork = New System.Windows.Forms.CheckBox()
        Me.chkSpoon = New System.Windows.Forms.CheckBox()
        Me.chkFullSet = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.radOne = New System.Windows.Forms.RadioButton()
        Me.radTwo = New System.Windows.Forms.RadioButton()
        Me.radFour = New System.Windows.Forms.RadioButton()
        Me.radEight = New System.Windows.Forms.RadioButton()
        Me.btnCalcPrice = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'chkKnife
        '
        Me.chkKnife.AutoSize = True
        Me.chkKnife.Location = New System.Drawing.Point(17, 44)
        Me.chkKnife.Name = "chkKnife"
        Me.chkKnife.Size = New System.Drawing.Size(50, 17)
        Me.chkKnife.TabIndex = 0
        Me.chkKnife.Text = "Knife"
        Me.chkKnife.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(48, 47)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Brands"
        '
        'lstBrands
        '
        Me.lstBrands.FormattingEnabled = True
        Me.lstBrands.Items.AddRange(New Object() {"Ardennes", "Jarrier", "Princeton", "Regency", "Tritan"})
        Me.lstBrands.Location = New System.Drawing.Point(29, 81)
        Me.lstBrands.Name = "lstBrands"
        Me.lstBrands.Size = New System.Drawing.Size(124, 147)
        Me.lstBrands.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkFullSet)
        Me.GroupBox1.Controls.Add(Me.chkSpoon)
        Me.GroupBox1.Controls.Add(Me.chkFork)
        Me.GroupBox1.Controls.Add(Me.chkKnife)
        Me.GroupBox1.Location = New System.Drawing.Point(265, 81)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(123, 212)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Items"
        '
        'chkFork
        '
        Me.chkFork.AutoSize = True
        Me.chkFork.Location = New System.Drawing.Point(17, 67)
        Me.chkFork.Name = "chkFork"
        Me.chkFork.Size = New System.Drawing.Size(47, 17)
        Me.chkFork.TabIndex = 1
        Me.chkFork.Text = "Fork"
        Me.chkFork.UseVisualStyleBackColor = True
        '
        'chkSpoon
        '
        Me.chkSpoon.AutoSize = True
        Me.chkSpoon.Location = New System.Drawing.Point(17, 90)
        Me.chkSpoon.Name = "chkSpoon"
        Me.chkSpoon.Size = New System.Drawing.Size(57, 17)
        Me.chkSpoon.TabIndex = 2
        Me.chkSpoon.Text = "Spoon"
        Me.chkSpoon.UseVisualStyleBackColor = True
        '
        'chkFullSet
        '
        Me.chkFullSet.AutoSize = True
        Me.chkFullSet.Location = New System.Drawing.Point(17, 176)
        Me.chkFullSet.Name = "chkFullSet"
        Me.chkFullSet.Size = New System.Drawing.Size(61, 17)
        Me.chkFullSet.TabIndex = 4
        Me.chkFullSet.Text = "Full Set"
        Me.chkFullSet.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.radEight)
        Me.GroupBox2.Controls.Add(Me.radFour)
        Me.GroupBox2.Controls.Add(Me.radTwo)
        Me.GroupBox2.Controls.Add(Me.radOne)
        Me.GroupBox2.Location = New System.Drawing.Point(568, 81)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(123, 147)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Quantity"
        '
        'radOne
        '
        Me.radOne.AutoSize = True
        Me.radOne.Location = New System.Drawing.Point(18, 44)
        Me.radOne.Name = "radOne"
        Me.radOne.Size = New System.Drawing.Size(31, 17)
        Me.radOne.TabIndex = 0
        Me.radOne.TabStop = True
        Me.radOne.Text = "1"
        Me.radOne.UseVisualStyleBackColor = True
        '
        'radTwo
        '
        Me.radTwo.AutoSize = True
        Me.radTwo.Location = New System.Drawing.Point(18, 67)
        Me.radTwo.Name = "radTwo"
        Me.radTwo.Size = New System.Drawing.Size(31, 17)
        Me.radTwo.TabIndex = 1
        Me.radTwo.TabStop = True
        Me.radTwo.Text = "2"
        Me.radTwo.UseVisualStyleBackColor = True
        '
        'radFour
        '
        Me.radFour.AutoSize = True
        Me.radFour.Location = New System.Drawing.Point(18, 90)
        Me.radFour.Name = "radFour"
        Me.radFour.Size = New System.Drawing.Size(31, 17)
        Me.radFour.TabIndex = 2
        Me.radFour.TabStop = True
        Me.radFour.Text = "4"
        Me.radFour.UseVisualStyleBackColor = True
        '
        'radEight
        '
        Me.radEight.AutoSize = True
        Me.radEight.Location = New System.Drawing.Point(18, 113)
        Me.radEight.Name = "radEight"
        Me.radEight.Size = New System.Drawing.Size(31, 17)
        Me.radEight.TabIndex = 3
        Me.radEight.TabStop = True
        Me.radEight.Text = "8"
        Me.radEight.UseVisualStyleBackColor = True
        '
        'btnCalcPrice
        '
        Me.btnCalcPrice.Location = New System.Drawing.Point(568, 282)
        Me.btnCalcPrice.Name = "btnCalcPrice"
        Me.btnCalcPrice.Size = New System.Drawing.Size(123, 43)
        Me.btnCalcPrice.TabIndex = 6
        Me.btnCalcPrice.Text = "Price"
        Me.btnCalcPrice.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnCalcPrice)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lstBrands)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Selecting Cutlery"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents chkKnife As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents lstBrands As ListBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents chkFullSet As CheckBox
    Friend WithEvents chkSpoon As CheckBox
    Friend WithEvents chkFork As CheckBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents radEight As RadioButton
    Friend WithEvents radFour As RadioButton
    Friend WithEvents radTwo As RadioButton
    Friend WithEvents radOne As RadioButton
    Friend WithEvents btnCalcPrice As Button
End Class
