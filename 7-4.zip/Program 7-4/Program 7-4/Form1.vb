﻿Public Class Form1
    Private Sub btnEnterPassword_Click(sender As Object, e As EventArgs) Handles btnEnterPassword.Click
        Dim Password, InputPassword As String
        Dim Attempt As Integer

        Password = "Secret"
        Attempt = 0
        Do
            Attempt = Attempt + 1
            InputPassword = InputBox("Enter password. This is attempt number" & Attempt)

        Loop Until (Attempt = 3) Or (InputPassword = Password)
        If InputPassword = Password Then
            MsgBox("This password is valid", , "Password Security System")
        Else
            MsgBox("This password is invalid", , "Password Security System")
        End If
    End Sub
End Class
