﻿Imports System.IO
Public Class MovieGenres

    Private Structure SmashStock
        Public Title As String
        Public Genre As String
        Public Director As String
        Public LeadActor As String                  'Creating the structure that will hold the  data.
        Public Duration As String
        Public ReleaseDate As String
        Public Certificate As String
        Public Is3D As String
    End Structure

    Private Sub cmdCount_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCount.Click

        '' INSTRUCTIONS TO CANDIDATES:
        '' Read through the code and familiarise yourself with its processes.
        '' Complete the misisng and broken lines below. ( . . . indicates missing or broken code )

        Dim CountNeeded As Integer
        Dim CountGot As Integer
        Dim I As Integer
        Dim MovieCount As Integer
        MovieCount = 0
        CountNeeded = 0
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        If txtTitle.Text.Length > "225" Then MsgBox("Too many charactors in Title") : Exit Sub
        If txtGenre.Text.Length > "225" Then MsgBox("Too many charactors in Genre") : Exit Sub
        If txtTitle.Text.Length > "225" Then MsgBox("Too many charactors in Title") : Exit Sub
        If txt Then
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            If Not txtTitle.Text = "" Then CountNeeded = CountNeeded + 1
        . . .
        . . .
        . . .
        . . .
        . . .
        . . .
        . . .

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        If CountNeeded = 0 Then MsgBox("Please enter something to count!") : Exit Sub

        Dim MovieData() As String = File.ReadAllLines(Dir$("Movies.txt"))
        For I = 0 To UBound(MovieData)
            CountGot = 0
            If Trim(Mid(MovieData(I), 1, 225)) = txtTitle.Text And Not txtTitle.Text = "" Then CountGot = CountGot + 1
            . . .
            . . .
            . . .
            . . .
            . . .
            . . .
            . . .

            If CountGot = CountNeeded Then MovieCount = MovieCount + 1 ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''If attributes match, add to the count.
        Next I
        MsgBox(. . .)
    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim SmashstockData As New SmashStock
        Dim sw As New System.IO.StreamWriter(Dir$("Movies.txt"), True)
        SmashstockData.Title = LSet(txtTitle.Text, 225)
        SmashstockData.Genre = LSet(txtGenre.Text, 25)
        SmashstockData.Director = LSet(txtDirector.Text, 30)
        SmashstockData.LeadActor = LSet(txtLeadActor.Text, 30)                      'Filling the structure with data.
        SmashstockData.Duration = LSet(txtDuration.Text, 3)
        SmashstockData.ReleaseDate = LSet(TxtReleaseDate.Text, 8)
        SmashstockData.Certificate = LSet(txtCertificate.Text, 2)
        SmashstockData.Is3D = LSet(txtIs3D.Text, 1)

        sw.WriteLine(SmashstockData.Title & SmashstockData.Genre & SmashstockData.Director & SmashstockData.LeadActor & SmashstockData.Duration & SmashstockData.ReleaseDate & SmashstockData.Certificate & SmashstockData.Is3D)
        sw.Close()                                                                  'Always need to close afterwards
    End Sub

    Private Sub MovieGenreComplete_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Dir$("Movies.txt") = "" Then
            Dim sw As New StreamWriter(Application.StartupPath & "\Movies.txt", True)    'This makes sure there is actually a database to enter/read data. If not, it creates a new blank one.
            sw.WriteLine("                                                                                                                                                                                                                                                                                                                                    ")
            sw.Close()
            MsgBox("A new database has been created", vbExclamation, "Warning!")
        End If
    End Sub
End Class
