﻿Public Class Form1
    Dim FirstNumber As Integer 'Stores first number
    Dim SecondNumber As Integer 'Stores second number
    Dim Total As Integer 'Stores sum of the 2 numbers
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FirstNumber = InputBox("Enter your first number")
        SecondNumber = InputBox("Enter your second number")
        Total = FirstNumber + SecondNumber
        lblTotal.Text = Total
    End Sub
End Class
