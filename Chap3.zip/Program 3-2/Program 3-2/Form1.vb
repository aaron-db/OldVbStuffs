﻿Public Class Form1
    Dim Surname As String
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles MyBase.Load
        Surname = "Green"
        lblGlobal.Text = Surname
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Dim Surname As String
        Surname = "Brown"
        lblLocal.Text = Surname
    End Sub
End Class
