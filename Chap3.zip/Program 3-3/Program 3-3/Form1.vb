﻿Public Class Form1
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Static Number As Integer
        Number = Number + 1
        lstOutput.Items.Add("Number of Clicks = " & Number)
    End Sub
End Class
