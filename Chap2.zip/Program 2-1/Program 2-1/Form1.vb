﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        FirstCountries.Items.Add(txtCountry.Text) 'Add contents of text box to List box display
        txtCountry.Text = "" 'Clears the text box
        txtCountry.Focus() 'Put cursor in text box ready for next country
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        FirstCountries.Items.RemoveAt(FirstCountries.SelectedIndex) 'Delete selected item from list of displayed items
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        FirstCountries.Items.Clear() 'Delete all items displayed in list box
    End Sub
End Class
