﻿Public Class Form1
    Dim FirstNum, SecondNum As Single
    Dim Message As String

    Private Sub btnLabel_Click(sender As Object, e As EventArgs) Handles btnLabel.Click
        FirstNum = txtFirstNumber.Text
        SecondNum = txtSecondNumber.Text
        Message = "The Results are as follows:" & vbNewLine & vbNewLine
        Message = Message & "Addition:" & FirstNum + SecondNum & vbNewLine
        Message = Message & "Subtraction:" & FirstNum - SecondNum & vbNewLine
        Message = Message & "Multiplication:" & FirstNum * SecondNum & vbNewLine
        Message = Message & "Divison:" & FirstNum / SecondNum
        lblOutput.Text = Message
    End Sub

    Private Sub btnTextBox_Click(sender As Object, e As EventArgs) Handles btnTextBox.Click
        FirstNum = txtFirstNumber.Text
        SecondNum = txtSecondNumber.Text
        Message = "The Results are as follows:" & vbNewLine & vbNewLine
        Message = Message & "Addition:" & FirstNum + SecondNum & vbNewLine
        Message = Message & "Subtraction:" & FirstNum - SecondNum & vbNewLine
        Message = Message & "Multiplication:" & FirstNum * SecondNum & vbNewLine
        Message = Message & "Divison:" & FirstNum / SecondNum
        txtOutput.Text = Message
    End Sub

    Private Sub btnMessageBox_Click(sender As Object, e As EventArgs) Handles btnMessageBox.Click
        FirstNum = txtFirstNumber.Text
        SecondNum = txtSecondNumber.Text
        Message = "The Results are as follows:" & vbCr & vbCr
        Message = Message & "Addition:" & FirstNum + SecondNum & vbCr
        Message = Message & "Subtraction:" & FirstNum - SecondNum & Chr(13)
        Message = Message & "Multiplication:" & FirstNum * SecondNum & Chr(10)
        Message = Message & "Divison:" & FirstNum / SecondNum
        MsgBox(Message)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
