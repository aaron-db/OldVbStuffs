﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtFirstNumber = New System.Windows.Forms.TextBox()
        Me.txtSecondNumber = New System.Windows.Forms.TextBox()
        Me.txtOutput = New System.Windows.Forms.TextBox()
        Me.lblOutput = New System.Windows.Forms.Label()
        Me.btnLabel = New System.Windows.Forms.Button()
        Me.btnTextBox = New System.Windows.Forms.Button()
        Me.btnMessageBox = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtFirstNumber
        '
        Me.txtFirstNumber.Location = New System.Drawing.Point(130, 45)
        Me.txtFirstNumber.Name = "txtFirstNumber"
        Me.txtFirstNumber.Size = New System.Drawing.Size(105, 20)
        Me.txtFirstNumber.TabIndex = 0
        '
        'txtSecondNumber
        '
        Me.txtSecondNumber.Location = New System.Drawing.Point(602, 45)
        Me.txtSecondNumber.Name = "txtSecondNumber"
        Me.txtSecondNumber.Size = New System.Drawing.Size(106, 20)
        Me.txtSecondNumber.TabIndex = 1
        '
        'txtOutput
        '
        Me.txtOutput.Location = New System.Drawing.Point(494, 95)
        Me.txtOutput.Multiline = True
        Me.txtOutput.Name = "txtOutput"
        Me.txtOutput.ReadOnly = True
        Me.txtOutput.Size = New System.Drawing.Size(214, 210)
        Me.txtOutput.TabIndex = 2
        '
        'lblOutput
        '
        Me.lblOutput.AutoSize = True
        Me.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutput.Location = New System.Drawing.Point(59, 98)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Size = New System.Drawing.Size(2, 15)
        Me.lblOutput.TabIndex = 3
        '
        'btnLabel
        '
        Me.btnLabel.Location = New System.Drawing.Point(51, 360)
        Me.btnLabel.Name = "btnLabel"
        Me.btnLabel.Size = New System.Drawing.Size(109, 52)
        Me.btnLabel.TabIndex = 4
        Me.btnLabel.Text = "Label"
        Me.btnLabel.UseVisualStyleBackColor = True
        '
        'btnTextBox
        '
        Me.btnTextBox.Location = New System.Drawing.Point(218, 360)
        Me.btnTextBox.Name = "btnTextBox"
        Me.btnTextBox.Size = New System.Drawing.Size(109, 52)
        Me.btnTextBox.TabIndex = 5
        Me.btnTextBox.Text = "Text Box"
        Me.btnTextBox.UseVisualStyleBackColor = True
        '
        'btnMessageBox
        '
        Me.btnMessageBox.Location = New System.Drawing.Point(394, 360)
        Me.btnMessageBox.Name = "btnMessageBox"
        Me.btnMessageBox.Size = New System.Drawing.Size(109, 52)
        Me.btnMessageBox.TabIndex = 6
        Me.btnMessageBox.Text = "Message Box"
        Me.btnMessageBox.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnMessageBox)
        Me.Controls.Add(Me.btnTextBox)
        Me.Controls.Add(Me.btnLabel)
        Me.Controls.Add(Me.lblOutput)
        Me.Controls.Add(Me.txtOutput)
        Me.Controls.Add(Me.txtSecondNumber)
        Me.Controls.Add(Me.txtFirstNumber)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtFirstNumber As TextBox
    Friend WithEvents txtSecondNumber As TextBox
    Friend WithEvents txtOutput As TextBox
    Friend WithEvents lblOutput As Label
    Friend WithEvents btnLabel As Button
    Friend WithEvents btnTextBox As Button
    Friend WithEvents btnMessageBox As Button
End Class
