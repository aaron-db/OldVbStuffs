﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.btnGoodMessage = New System.Windows.Forms.Button()
        Me.btnBadMessage = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblMessage
        '
        Me.lblMessage.AutoSize = True
        Me.lblMessage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMessage.Location = New System.Drawing.Point(235, 33)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(2, 26)
        Me.lblMessage.TabIndex = 0
        '
        'btnGoodMessage
        '
        Me.btnGoodMessage.Location = New System.Drawing.Point(91, 312)
        Me.btnGoodMessage.Name = "btnGoodMessage"
        Me.btnGoodMessage.Size = New System.Drawing.Size(122, 53)
        Me.btnGoodMessage.TabIndex = 1
        Me.btnGoodMessage.Text = "Good Message"
        Me.btnGoodMessage.UseVisualStyleBackColor = True
        '
        'btnBadMessage
        '
        Me.btnBadMessage.Location = New System.Drawing.Point(586, 312)
        Me.btnBadMessage.Name = "btnBadMessage"
        Me.btnBadMessage.Size = New System.Drawing.Size(122, 53)
        Me.btnBadMessage.TabIndex = 2
        Me.btnBadMessage.Text = "Bad Message"
        Me.btnBadMessage.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnBadMessage)
        Me.Controls.Add(Me.btnGoodMessage)
        Me.Controls.Add(Me.lblMessage)
        Me.Name = "Form1"
        Me.Text = "Change A Message"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblMessage As Label
    Friend WithEvents btnGoodMessage As Button
    Friend WithEvents btnBadMessage As Button
End Class
