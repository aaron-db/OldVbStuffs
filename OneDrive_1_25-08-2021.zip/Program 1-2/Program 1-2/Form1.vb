﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblMessage.Click

    End Sub

    Private Sub btnGoodMessage_Click(sender As Object, e As EventArgs) Handles btnGoodMessage.Click
        lblMessage.Text = "I LIKE Visual Basic .NET"
    End Sub

    Private Sub btnBadMessage_Click(sender As Object, e As EventArgs) Handles btnBadMessage.Click
        lblMessage.Text = "I HATE Visual Basic .NET"
    End Sub
End Class
