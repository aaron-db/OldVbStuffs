﻿Public Class frmMain
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DSDB.tblLevel' table. You can move, or remove it, as needed.
        Me.TblLevelTableAdapter.Fill(Me.DSDB.tblLevel)
        'TODO: This line of code loads data into the 'DSDB.tblSession' table. You can move, or remove it, as needed.
        Me.TblSessionTableAdapter.Fill(Me.DSDB.tblSession)
        'TODO: This line of code loads data into the 'DSDB.tblUser' table. You can move, or remove it, as needed.
        Me.TblUserTableAdapter.Fill(Me.DSDB.tblUser)

        FRMLogon.ShowDialog()

    End Sub
End Class