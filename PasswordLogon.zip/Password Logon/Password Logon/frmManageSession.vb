﻿Public Class frmManageSession
    Private Sub frmManageSession_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DSDB.tblSession' table. You can move, or remove it, as needed.
        Me.TblSessionTableAdapter.Fill(Me.DSDB.tblSession)

    End Sub
End Class