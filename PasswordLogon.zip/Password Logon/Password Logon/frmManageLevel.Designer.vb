﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmManageLevel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmManageLevel))
        Me.dgvLevel = New System.Windows.Forms.DataGridView()
        Me.DSDB = New Password_Logon.DSDB()
        Me.TblLevelBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblLevelTableAdapter = New Password_Logon.DSDBTableAdapters.tblLevelTableAdapter()
        Me.LEVELIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LevelnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DescriptionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NaviLevel = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.lblLevelNameDisplay = New System.Windows.Forms.Label()
        Me.TblLevelBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.dgvLevel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DSDB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblLevelBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NaviLevel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.NaviLevel.SuspendLayout()
        CType(Me.TblLevelBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvLevel
        '
        Me.dgvLevel.AutoGenerateColumns = False
        Me.dgvLevel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvLevel.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.LEVELIDDataGridViewTextBoxColumn, Me.LevelnameDataGridViewTextBoxColumn, Me.DescriptionDataGridViewTextBoxColumn})
        Me.dgvLevel.DataSource = Me.TblLevelBindingSource
        Me.dgvLevel.Location = New System.Drawing.Point(182, 85)
        Me.dgvLevel.Name = "dgvLevel"
        Me.dgvLevel.Size = New System.Drawing.Size(343, 120)
        Me.dgvLevel.TabIndex = 0
        '
        'DSDB
        '
        Me.DSDB.DataSetName = "DSDB"
        Me.DSDB.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblLevelBindingSource
        '
        Me.TblLevelBindingSource.DataMember = "tblLevel"
        Me.TblLevelBindingSource.DataSource = Me.DSDB
        '
        'TblLevelTableAdapter
        '
        Me.TblLevelTableAdapter.ClearBeforeFill = True
        '
        'LEVELIDDataGridViewTextBoxColumn
        '
        Me.LEVELIDDataGridViewTextBoxColumn.DataPropertyName = "LEVELID"
        Me.LEVELIDDataGridViewTextBoxColumn.HeaderText = "LEVELID"
        Me.LEVELIDDataGridViewTextBoxColumn.Name = "LEVELIDDataGridViewTextBoxColumn"
        '
        'LevelnameDataGridViewTextBoxColumn
        '
        Me.LevelnameDataGridViewTextBoxColumn.DataPropertyName = "Levelname"
        Me.LevelnameDataGridViewTextBoxColumn.HeaderText = "Levelname"
        Me.LevelnameDataGridViewTextBoxColumn.Name = "LevelnameDataGridViewTextBoxColumn"
        '
        'DescriptionDataGridViewTextBoxColumn
        '
        Me.DescriptionDataGridViewTextBoxColumn.DataPropertyName = "Description"
        Me.DescriptionDataGridViewTextBoxColumn.HeaderText = "Description"
        Me.DescriptionDataGridViewTextBoxColumn.Name = "DescriptionDataGridViewTextBoxColumn"
        '
        'NaviLevel
        '
        Me.NaviLevel.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.NaviLevel.CountItem = Me.BindingNavigatorCountItem
        Me.NaviLevel.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.NaviLevel.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem})
        Me.NaviLevel.Location = New System.Drawing.Point(0, 0)
        Me.NaviLevel.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.NaviLevel.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.NaviLevel.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.NaviLevel.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.NaviLevel.Name = "NaviLevel"
        Me.NaviLevel.PositionItem = Me.BindingNavigatorPositionItem
        Me.NaviLevel.Size = New System.Drawing.Size(800, 25)
        Me.NaviLevel.TabIndex = 1
        Me.NaviLevel.Text = "BindingNavigator1"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'lblLevelNameDisplay
        '
        Me.lblLevelNameDisplay.AutoSize = True
        Me.lblLevelNameDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblLevelNameDisplay.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblLevelBindingSource1, "Levelname", True))
        Me.lblLevelNameDisplay.Location = New System.Drawing.Point(182, 250)
        Me.lblLevelNameDisplay.Name = "lblLevelNameDisplay"
        Me.lblLevelNameDisplay.Size = New System.Drawing.Size(2, 15)
        Me.lblLevelNameDisplay.TabIndex = 4
        '
        'TblLevelBindingSource1
        '
        Me.TblLevelBindingSource1.DataMember = "tblLevel"
        Me.TblLevelBindingSource1.DataSource = Me.DSDB
        '
        'frmManageLevel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblLevelNameDisplay)
        Me.Controls.Add(Me.NaviLevel)
        Me.Controls.Add(Me.dgvLevel)
        Me.Name = "frmManageLevel"
        Me.Text = "frmManageLevel"
        CType(Me.dgvLevel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DSDB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblLevelBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NaviLevel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.NaviLevel.ResumeLayout(False)
        Me.NaviLevel.PerformLayout()
        CType(Me.TblLevelBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvLevel As DataGridView
    Friend WithEvents DSDB As DSDB
    Friend WithEvents TblLevelBindingSource As BindingSource
    Friend WithEvents TblLevelTableAdapter As DSDBTableAdapters.tblLevelTableAdapter
    Friend WithEvents LEVELIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LevelnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DescriptionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NaviLevel As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents lblLevelNameDisplay As Label
    Friend WithEvents TblLevelBindingSource1 As BindingSource
End Class
