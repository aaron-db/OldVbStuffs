﻿Public Class FRMLogon
    Public DBUsername, DBPassword As String
    Public DBLocation As Integer

    Private Sub lblForgotten_Click(sender As Object, e As EventArgs) Handles lblForgotten.Click
        frmChangePass.ShowDialog()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim LastRow, UserID, LoopCount, RowCount, Level, DBLevel As Integer
        Dim Username, Password As String
        Dim UserFound As Boolean = False
        Dim StartTime, EndTime As DateTime
        Dim MyDate As DateTime

        Username = txtUser.Text
        Password = txtPassword.Text
        RowCount = frmMain.DSDB.tblUser.Rows.Count - 1
        LoopCount = 0

        Do While (LoopCount <= RowCount) And (UserFound = False)
            DBUsername = frmMain.DSDB.Tables("tblUser").Rows(LoopCount)(1).ToString()
            If Username = DBUsername Then
                UserFound = True
            Else
                LoopCount = LoopCount + 1
            End If
        Loop
        DBLocation = LoopCount
        If Not UserFound Then
            MsgBox("Username not found in database, please try again.", , "Error")
        Else
            DBPassword = frmMain.DSDB.Tables("tblUser").Rows(LoopCount)(2).ToString()
            If Password <> DBPassword Then
                MsgBox("Password not found with this username, please try again", , "Error")
            Else
                DBLevel = frmMain.DSDB.Tables("tblUser").Rows(LoopCount)(3).ToString()
                Level = DBLevel
                StartTime = TimeOfDay 'Session Info
                MyDate = Today 'Session Info
                UserID = frmMain.DSDB.Tables("tblUser").Rows(LoopCount)(0) 'Session Info
                txtUser.Text = ""
                txtPassword.Text = ""
                Hide()

                Select Case DBLevel
                    Case 1
                        frmAdmin.ShowDialog()
                    Case 2
                        frmManager.ShowDialog()
                    Case 3
                        frmUser.ShowDialog()
                End Select
                EndTime = TimeOfDay 'Session Info

                'Example 1
                Dim NewSessionRow = frmMain.DSDB.tblSession.NewtblSessionRow()
                NewSessionRow.TimeIn = StartTime
                NewSessionRow.TimeOut = EndTime
                NewSessionRow.DateIn = MyDate
                NewSessionRow.USERID = UserID
                frmMain.DSDB.tblSession.Rows.Add(NewSessionRow)

                Show()
            End If
        End If
    End Sub
End Class