﻿Public Class frmChangePass
    Private Sub frmChangePass_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim UserWelcome As String
        UserWelcome = InputBox("Please enter your Username for the database.", "Changing Password")
        lblWelcome
    End Sub
End Class