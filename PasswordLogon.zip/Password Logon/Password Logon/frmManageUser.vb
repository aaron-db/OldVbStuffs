﻿Public Class frmManageUser

    Private Sub frmManageUser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DSDB.tblLevel' table. You can move, or remove it, as needed.
        Me.TblLevelTableAdapter.Fill(Me.DSDB.tblLevel)
        'TODO: This line of code loads data into the 'DSDB.tblLevel' table. You can move, or remove it, as needed.
        TblUserTableAdapter.Fill(DSDB.tblUser)
        lblOutput.Text = "Current record is: " & bsUser.Position - 1 & " Of: " & bsUser.Count
    End Sub
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSaveDB.Click
        TblUserTableAdapter.Update(DSDB.tblUser)
        TblUserTableAdapter.Fill(DSDB.tblUser)
    End Sub
    Private Sub btnFirst_Click(sender As Object, e As EventArgs) Handles btnFirst.Click
        bsUser.MoveFirst()
    End Sub
    Private Sub btnPrev_Click(sender As Object, e As EventArgs) Handles btnPrev.Click
        bsUser.MovePrevious()
    End Sub
    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        bsUser.MoveNext()
    End Sub
    Private Sub btnLast_Click(sender As Object, e As EventArgs) Handles btnLast.Click
        bsUser.MoveLast()
    End Sub
    Private Sub btnAddNew_Click(sender As Object, e As EventArgs) Handles btnAddNew.Click
        bsUser.AddNew()
    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        bsUser.RemoveCurrent()
    End Sub

    Private Sub btnSetPass_Click(sender As Object, e As EventArgs) Handles btnSetPass.Click
        DSDB.Tables("tblUser").Rows(bsUser.Position)(2) = txtPassChange
    End Sub

    Private Sub bsUser_PositionChanged(sender As Object, e As EventArgs) Handles bsUser.PositionChanged
        lblOutput.Text = "Current record is: " & bsUser.Position + 1 & " of: " & bsUser.Count
    End Sub

    Private Sub btnSaveED_Click(sender As Object, e As EventArgs) Handles btnSaveED.Click
        bsUser.EndEdit()
    End Sub

    Private Sub btnAdmin_Click(sender As Object, e As EventArgs) Handles btnAdmin.Click
        bsUser.Filter = "level = 1" 'Admin Filter
    End Sub

    Private Sub btnManager_Click(sender As Object, e As EventArgs) Handles btnManager.Click
        bsUser.Filter = "level = 2" 'Manager filter
    End Sub

    Private Sub btnStandard_Click(sender As Object, e As EventArgs) Handles btnStandard.Click
        bsUser.Filter = "Level = 3" 'Standard filter
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        bsUser.Filter = "" 'Clearing filter to show all
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        bsUser.Filter = "level = " & ComboBox1.SelectedValue 'Using a Combobox to apply filter
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Close()
    End Sub
End Class