﻿Public Class frmAdmin
    Private Sub btnDBView_Click(sender As Object, e As EventArgs) Handles btnManageUser.Click
        frmManageUser.ShowDialog()
    End Sub

    Private Sub btnManageSession_Click(sender As Object, e As EventArgs) Handles btnManageSession.Click
        frmManageSession.ShowDialog()
    End Sub

    Private Sub btnManageLevel_Click(sender As Object, e As EventArgs) Handles btnManageLevel.Click
        frmManageLevel.ShowDialog()
    End Sub
End Class