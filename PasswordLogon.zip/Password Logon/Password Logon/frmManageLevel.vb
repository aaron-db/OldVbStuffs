﻿Public Class frmManageLevel
    Private Sub frmManageLevel_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DSDB.tblLevel' table. You can move, or remove it, as needed.
        Me.TblLevelTableAdapter.Fill(Me.DSDB.tblLevel)

    End Sub
End Class