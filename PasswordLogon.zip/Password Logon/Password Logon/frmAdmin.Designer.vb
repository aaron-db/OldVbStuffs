﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnManageUser = New System.Windows.Forms.Button()
        Me.btnManageSession = New System.Windows.Forms.Button()
        Me.btnManageLevel = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnManageUser
        '
        Me.btnManageUser.Location = New System.Drawing.Point(96, 73)
        Me.btnManageUser.Name = "btnManageUser"
        Me.btnManageUser.Size = New System.Drawing.Size(124, 65)
        Me.btnManageUser.TabIndex = 0
        Me.btnManageUser.Text = "View/Edit User Database"
        Me.btnManageUser.UseVisualStyleBackColor = True
        '
        'btnManageSession
        '
        Me.btnManageSession.Location = New System.Drawing.Point(242, 73)
        Me.btnManageSession.Name = "btnManageSession"
        Me.btnManageSession.Size = New System.Drawing.Size(124, 65)
        Me.btnManageSession.TabIndex = 1
        Me.btnManageSession.Text = "View/Edit Session Database"
        Me.btnManageSession.UseVisualStyleBackColor = True
        '
        'btnManageLevel
        '
        Me.btnManageLevel.Location = New System.Drawing.Point(388, 73)
        Me.btnManageLevel.Name = "btnManageLevel"
        Me.btnManageLevel.Size = New System.Drawing.Size(124, 65)
        Me.btnManageLevel.TabIndex = 2
        Me.btnManageLevel.Text = "View/Edit Level Database"
        Me.btnManageLevel.UseVisualStyleBackColor = True
        '
        'frmAdmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnManageLevel)
        Me.Controls.Add(Me.btnManageSession)
        Me.Controls.Add(Me.btnManageUser)
        Me.Name = "frmAdmin"
        Me.Text = "Administrator"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnManageUser As Button
    Friend WithEvents btnManageSession As Button
    Friend WithEvents btnManageLevel As Button
End Class
