﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.BSUser = New System.Windows.Forms.BindingSource(Me.components)
        Me.DSDB = New Password_Logon.DSDB()
        Me.TblUserTableAdapter = New Password_Logon.DSDBTableAdapters.tblUserTableAdapter()
        Me.BSSession = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblSessionTableAdapter = New Password_Logon.DSDBTableAdapters.tblSessionTableAdapter()
        Me.BSLevel = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblLevelTableAdapter = New Password_Logon.DSDBTableAdapters.tblLevelTableAdapter()
        CType(Me.BSUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DSDB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BSSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BSLevel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BSUser
        '
        Me.BSUser.DataMember = "tblUser"
        Me.BSUser.DataSource = Me.DSDB
        '
        'DSDB
        '
        Me.DSDB.DataSetName = "DSDB"
        Me.DSDB.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblUserTableAdapter
        '
        Me.TblUserTableAdapter.ClearBeforeFill = True
        '
        'BSSession
        '
        Me.BSSession.DataMember = "tblSession"
        Me.BSSession.DataSource = Me.DSDB
        '
        'TblSessionTableAdapter
        '
        Me.TblSessionTableAdapter.ClearBeforeFill = True
        '
        'BSLevel
        '
        Me.BSLevel.DataMember = "tblLevel"
        Me.BSLevel.DataSource = Me.DSDB
        '
        'TblLevelTableAdapter
        '
        Me.TblLevelTableAdapter.ClearBeforeFill = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(907, 495)
        Me.ControlBox = False
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.Text = "Main"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.BSUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DSDB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BSSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BSLevel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BSUser As BindingSource
    Friend WithEvents DSDB As DSDB
    Friend WithEvents TblUserTableAdapter As DSDBTableAdapters.tblUserTableAdapter
    Friend WithEvents BSSession As BindingSource
    Friend WithEvents TblSessionTableAdapter As DSDBTableAdapters.tblSessionTableAdapter
    Friend WithEvents BSLevel As BindingSource
    Friend WithEvents TblLevelTableAdapter As DSDBTableAdapters.tblLevelTableAdapter
End Class
